import cv2
import numpy as np
import os
from PIL import Image
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

train = open('train.txt',"r")
test = pd.read_csv("submission_example.csv")

'''
image_paths = []
image_classes = []
Length = []
Length.append(0)
class_id = 0
for training_name in training_names:
    dir = os.path.join(train_path, training_name)
    class_path = list(paths.list_images(dir))
    image_paths += class_path
    image_classes += [class_id] * len(class_path)
    Length.append(len(class_path))
    class_id += 1
'''
X = []
y = []
Face = []
Test = []
#image_paths = []
#image_classes = []
#Length = []
#Length.append(0)
#class_id = 0
X_Test = []
y_Test = []
'''
for training_name in training_names:
    dir = os.path.join(train_path, training_name)
    class_path = list(paths.list_images(dir))
    image_paths += class_path
    image_classes += [class_id] * len(class_path)
    Length.append(len(class_path))
    class_id += 1
'''
for T in iter(train):
    X_tmp,y_tmp = [i for i in T.split()]
    X.append(X_tmp)
    y.append(y_tmp)
train.close()
#defined area ===========================================================
"""
def read_directory(image):
    global ReturnValue
    face = cv2.CascadeClassifier('C:\opencv\opencv\sources\data\haarcascades\haarcascade_frontalface_alt.xml')
    img = cv2.imread(image)
    Size = (img.shape[1],img.shape[0])
    Frame = cv2.resize(img, Size)
    faces = np.array(0)

    for (x, y, w, h) in faces: 
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        crop_img = img[y:y+h, x:x+w]
        gray = cv2.cvtColor(crop_img, cv2.COLOR_RGB2GRAY) # 灰度
        img = Image.fromarray(gray)
        img = img.resize((250,250), Image.ANTIALIAS)
        ReturnValue = np.array(img)
    return ReturnValue
"""

def Detection(image):
    global ReturnValue
    facedata = 'C:\opencv\opencv\sources\data\haarcascades\haarcascade_frontalface_alt.xml'
    cascade = cv2.CascadeClassifier(facedata)
    img = cv2.imread(image)
    Size = (img.shape[1],img.shape[0])
    Frame = cv2.resize(img, Size)
    faces = cascade.detectMultiScale(Frame)
    #faces = face.detectMultiScale(gray,scaleFactor=1.2,minNeighbors=4)
    for f in faces:
        x, y, w, h = [ v for v in f ]
        cv2.rectangle(img, (x,y), (x+w,y+h), (255,255,255))
        SF = img[y:y+h, x:x+w]
        gray= cv2.cvtColor(SF, cv2.COLOR_BGR2GRAY)
        img = Image.fromarray(gray)
        img = img.resize((250,250), Image.ANTIALIAS)
        ReturnValue = np.array(img)
        ReturnValue = ReturnValue.flatten()
    return ReturnValue

#====================================================================

X_test = np.array(test['Id'])
''' 
des_list = []
for image_path in image_paths:
    im = cv2.imread(image_path)
    im = cv2.resize(im, (300, 300))
    kpts = sift.detect(im)
    kpts, des = sift.compute(im, kpts)
    des_list.append((des.flatten()))
'''
#if image_classes[class_id] == image_classes[class_di] :
for i in range(len(X)):
    Face.append(Detection(X[i]))

for i in range(len(X_test)):
    Test.append(Detection(X_test[i]))

X_train, X_test, y_train, y_Test = train_test_split(Face, y, test_size=0.2,stratify = y)

svclassifier = SVC(kernel='linear',probability = False)
svclassifier.fit(X_train, y_train)
y_pred = svclassifier.predict(Test)

df = pd.DataFrame(data=y_pred)
df.to_csv('F.csv')

